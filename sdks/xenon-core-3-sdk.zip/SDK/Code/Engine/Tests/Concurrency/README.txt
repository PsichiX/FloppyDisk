* Source code:
main.cpp
* Include search dirs:
<XenonCore3>/include/
* Static libraries dirs:
<XenonCore3>/libs/
