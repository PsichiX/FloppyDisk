* Source code:
main.cpp
* Include search dirs:
<XenonCore3>/include/
<IntuicioCompiler>/include/
* Static libraries dirs:
<XenonCore3>/libs/
<IntuicioCompiler>/libs/
