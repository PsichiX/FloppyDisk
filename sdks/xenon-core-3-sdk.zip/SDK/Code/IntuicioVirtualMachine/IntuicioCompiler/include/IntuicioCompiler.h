#include <XeCore/Common/String.h>

namespace XeCore
{
    namespace Intuicio
    {
        using namespace XeCore::Common;

        bool compile( const String& args, String& outStream );
    }
}
