# BUILD REQUIRES:
* Source code files:
TimusTinyBasicPlugin.cs
Constants.cs
* DLLS:
../Lib/IntuicioIdePlugin.dll
ICSharpCode.TextEditor.dll
